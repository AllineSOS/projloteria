<?php
// include 'funcoes.php';
include "cabecalho.php";
?>
<body>

		<div class="titulo">
			<h3>Jogos IFC</h3>

			<br>

		<div class="centro">
			<a href="escolheDezenas.php?cod=1">
			<li>Mega Sena</li>
			</a>

			<br>

			<a href="escolheDezenas.php?cod=2">
			<li>Quina</li>
			</a>

			<br>

			<a href="escolheDezenas.php?cod=3">
			<li>Loto Facil</li>
			</a>

			<br>

			<a href="escolheDezenas.php?cod=4">
			<li>Loto Mania</li>
			</a>


		</div>
</body>

